CREATE TABLE CUSTOMER(
	RRN				CHAR(7)		NOT NULL,
	Sex				CHAR,	
	Birth			DATE,
	Name			VARCHAR(10),
	PRIMARY KEY (RRN)
);

CREATE TABLE CAR(
	Car_Number		 CHAR(7)		NOT NULL,
	Car_Model		 VARCHAR(30),
	Disabled_vehicle CHAR(1) DEFAULT 'N'	CONSTRAINT boolean_Disabled_vehicle CHECK(Disabled_vehicle IN ('N','Y')),
	CRRN			 CHAR(7)		NOT NULL,
	PRIMARY KEY (Car_Number)
);

CREATE TABLE DEPARTMENT(
	Dnumber			NUMBER		NOT	NULL,
	Dname			VARCHAR(12)		NOT NULL,
	PRIMARY KEY (Dnumber)
);

CREATE TABLE STORE(
	STORE_ID		NUMBER			NOT NULL,
	Store_Location	VARCHAR(10),
	Opening_Hours	VARCHAR(11),
	Closing_Hours	VARCHAR(11),
	MAX_TC			NUMBER			NOT NULL,
	Dno 			NUMBER	not null,
	PRIMARY KEY (STORE_ID)
);

CREATE TABLE EMPLOYEE(
	EID			NUMBER		NOT	NULL,
	Sex			CHAR,
	Name		VARCHAR(10),
	Birth		DATE,
	Dno			NUMBER not null,
	Sid			NUMBER, 
	PRIMARY KEY (EID)
);

CREATE TABLE PARKING_LOT(
	PFloor					CHAR(3),
	Location				CHAR(4),
	Pno						NUMBER 		NOT NULL,
	UseAble					CHAR(1) DEFAULT 'N'	CONSTRAINT boolean_UseAble CHECK(UseAble IN ('N','Y')),
	Disable_Vehicle_Area 	CHAR(1) DEFAULT 'N'	CONSTRAINT boolean_Disable_Vehicle_Area CHECK(Disable_Vehicle_Area IN ('N','Y')),
	PDate					DATE not null,
	Dno 					NUMBER	not null,
	Rno						NUMBER DEFAULT 0,
	PRIMARY KEY (Pno,PDate)
);

CREATE TABLE STORE_RESERVATION(
	Rno					NUMBER			NOT NULL,
	RDate				DATE			NOT NULL,
	NoP					NUMBER			DEFAULT 1 NOT NULL,
	Sno					NUMBER,
	RRN			 		CHAR(7)		NOT NULL,
	PRIMARY KEY (Rno)
);

CREATE TABLE PARKING_RESERVATION(
	Rno					NUMBER			NOT NULL,
	Cno					CHAR(7)		NOT NULL, -- car number
	PRDate				DATE			NOT NULL,
	Pno					NUMBER			not NULL,
	Vehicle_Useable		CHAR(1) 	DEFAULT 'N' CONSTRAINT boolean_Vehicle_Useable CHECK(Vehicle_Useable IN ('N','Y')),
	RRN			 		CHAR(7)		NOT NULL,
	PRIMARY KEY (Rno)
);

CREATE TABLE DISCOUNT(
	SID					NUMBER			NOT NULL,
	DCName				VARCHAR(30)			NOT NULL, 
	How					VARCHAR(30),
	DCPercent			NUMBER,
	PRIMARY KEY (SID,DCName)
);

CREATE TABLE SEAT_INFO(
	SID					NUMBER			NOT NULL,
	Tno					NUMBER			NOT NULL,
	Maxnum				NUMBER,
	Enable_Reservation	CHAR(1) 	DEFAULT 'Y' CONSTRAINT boolean_Enable_Reservation CHECK(Enable_Reservation IN ('N','Y')),
	Rno					NUMBER DEFAULT 0,		
	PRIMARY KEY (SID,Tno)
);

alter table car add foreign key(crrn) references customer(rrn) ON DELETE CASCADE;
alter table discount add foreign key(sid) references store(STORE_ID) ON DELETE CASCADE;
alter table store add foreign key(dno) references department(dnumber) ON DELETE CASCADE;
alter table seat_info add foreign key(sid) references store(store_id) ON DELETE CASCADE;
alter table employee add foreign key(dno) references department(Dnumber) ON DELETE CASCADE;
alter table employee add foreign key(sid) references store(store_id) ON DELETE CASCADE;
alter table parking_lot add foreign key(dno) references department(dnumber) ON DELETE CASCADE;
alter table store_reservation add foreign key(sno) references store(store_id) ON DELETE CASCADE;
alter table store_reservation add foreign key(rrn) references customer(rrn) ON DELETE CASCADE;

alter table parking_reservation add foreign key(cno) references car(car_number) ON DELETE CASCADE;
alter table parking_reservation add foreign key(pno,prdate) references parking_lot(pno,pdate) ON DELETE CASCADE;
alter table parking_reservation add foreign key(rrn) references customer(rrn) ON DELETE CASCADE;



Commit;

