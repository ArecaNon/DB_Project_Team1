package teamproject; // package name 

import java.sql.*; // import JDBC package
import java.util.InputMismatchException;
import java.util.Scanner;

public class project1 {

	public static final String URL = "jdbc:oracle:thin:@localhost:1521:orcl";
	public static final String USER_ID = "teamproject";
	public static final String USER_PASSWD = "comp322";

	public static void main(String[] args) {

		Connection conn = null; // Connection object
		Statement stmt = null; // Statement object
		Scanner scanner = new Scanner(System.in);
		Integer num = 0;
		Integer check = 0;
		String name = null;
		String rrn = null;
		int exit = 0;
		try {
			// Load a JDBC driver for Oracle DBMS
			Class.forName("oracle.jdbc.driver.OracleDriver");
			// Get a Connection object
			System.out.println("Success!");
		} catch (ClassNotFoundException e) {
			System.err.println("error = " + e.getMessage());
			System.exit(1);
		}

		// Make a connection
		try {
			conn = DriverManager.getConnection(URL, USER_ID, USER_PASSWD);
			stmt = conn.createStatement();
			System.out.println("Connected.");
		} catch (SQLException ex) {
			ex.printStackTrace();
			System.err.println("Cannot get a connection: " + ex.getLocalizedMessage());
			System.err.println("Cannot get a connection: " + ex.getMessage());
			System.exit(1);
		}

		while (true) {// 초기 메뉴
			System.out.println("1. Sign up  2. Log In  3. Exit	");
			System.out.print("choose menu: ");
			num = scanner.nextInt();
			switch (num) {
			case 1:
				New_Cusotomer_Insert(conn, stmt);
				break;
			case 2:
				System.out.print("NAME: ");
				name = scanner.next();
				System.out.print("RRN(7digit): ");
				rrn = scanner.next();
				System.out.println();
				check = Login(conn, stmt, name, rrn);
				System.out.println();

				if (check == 1 && rrn.equals("1234567") == false)// 관리자 아닌 고객일때,
					while (true) {

						System.out.println(
								"1.Reservation  2.Check My Reservation  3.Search Store  4.Search Discount Information"
										+ "  5.Cancel Reservation  6.Search Seat  7.Print my car  8.Regist my car  9.exit");
						System.out.print("choose menu: ");
						Integer login_num = scanner.nextInt();

						switch (login_num) {
						case 1:
							New_Reservation_Insert(conn, stmt, rrn);
							break;
						case 2:
							Check_Reservation(conn, stmt, rrn);
							break;
						case 3:
							Search_Store(conn, stmt);
							break;
						case 4:
							Search_Discount_Info(conn, stmt);
							break;
						case 5:
							Cancel_Reservation(conn, stmt, rrn);
							break;
						case 6:
							Search_Store_Seat(conn, stmt);
							break;
						case 7:
							Print_My_Car(conn, stmt, rrn);
							break;
						case 8:
							Regist_My_Car(conn, stmt, rrn);
							break;
						case 9:
							exit = 1;
							break;
						default:
							System.out.println("input number 1~9 plz!");
						}
						if (exit == 1)
							break;

					}
				else if (check == 1 && rrn.equals("1234567"))// admin 일때
				{
					while (true) {
						System.out.println();
						System.out.println(
								"1. Insert  2. delete  3. search all table data  4. print admin query  5. exit");
						System.out.print("choose menu: ");
						Integer login_num = scanner.nextInt();

						switch (login_num) {
						case 1:
							do_Insert(conn, stmt);
							break;
						case 2:
							do_Delete(conn, stmt);
							break;
						case 3:
							do_Search(conn, stmt);
							break;
						case 4:
							Admin_Query(conn, stmt);
							break;
						case 5:
							exit = 1;
							break;
						default:
							System.out.println("input number 1~4 plz!");

						}
						if (exit == 1)
							break;
					}
				}
				break;
			case 3:
				exit = 1;
				break;
			default:
				System.out.println("input number 1~3 plz!");

			}
			if (exit == 1)
				break;

		}
		System.out.println("program quit");

		try {

			// Close the Statement object.
			stmt.close();
			// Close the Connection object.
			conn.close();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		scanner.close();
	}

	// 회원가입
	public static void New_Cusotomer_Insert(Connection conn, Statement stmt) {

		String sql = ""; // 필요한 정보 입력 받음
		PreparedStatement pstmt = null;
		System.out.println();
		String Car_Number = null;
		String Car_Model = null;
		String Disabled_vehicle = null;
		Scanner scanner = new Scanner(System.in);
		System.out.print("NAME: ");
		String name = scanner.next();
		System.out.print("BIRTH(yyyy-mm-dd): ");
		String birth = scanner.next();
		System.out.print("RRN(7digits): ");
		String rrn = scanner.next();
		System.out.print("SEX(M or F): ");
		String sex = scanner.next();

		System.out.print("register your car??(Y or N): ");// 차량 등록은 옵션
		String car_use = scanner.next();

		if (car_use.equals("Y")) {
			System.out.print("CAR NEMBER: ");
			Car_Number = scanner.next();
			System.out.print("CAR MODEL:  ");
			Car_Model = scanner.next();
			System.out.print("DISABLED VEHICLE(Y or N):  ");
			Disabled_vehicle = scanner.next();
		}

		try {
			sql = "INSERT INTO CUSTOMER (RRN,Sex,Birth,Name) VALUES(?,?,?,?)";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, rrn);
			pstmt.setString(2, sex);
			pstmt.setDate(3, java.sql.Date.valueOf(birth));
			pstmt.setString(4, name);
			pstmt.executeUpdate();

			if (car_use.equals("Y")) {
				sql = "INSERT INTO CAR (Car_Number,Car_Model,Disabled_vehicle,CRRN) VALUES(?,?,?,?)";
				pstmt = conn.prepareStatement(sql);
				pstmt.setString(1, Car_Number);
				pstmt.setString(2, Car_Model);
				pstmt.setString(3, Disabled_vehicle);
				pstmt.setString(4, rrn);
				pstmt.executeUpdate();
			}

		} catch (SQLException ex2) {
			System.err.println("sql error = " + ex2.getMessage());
			System.out.println("input error ");

			return;
		}
		System.out.println("Sign up success!! ");

	}

	// 로그인
	public static Integer Login(Connection conn, Statement stmt, String name, String rrn) {

		String sql = ""; // name 과 rrn 입력 받아 db 와 비교후 회원 판단
		PreparedStatement pstmt;
		Integer check = 0;
		ResultSet rs = null;
		try {
			sql = "SELECT NAME, RRN FROM CUSTOMER WHERE  Name = ? and RRN = ?";

			pstmt = conn.prepareStatement(sql);

			pstmt.setString(1, name);
			pstmt.setString(2, rrn);
			rs = pstmt.executeQuery();

			if (rs.next() != false && name.equals(rs.getString(1)) && rrn.equals(rs.getString(2))) {

				System.out.println(name + "! WECOME!");// 등록된 경우
				check = 1;
			} else {
				System.out.println(name + "! not in our service!");// 등뢱되지 않은 경우
			}

			rs.close();

		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("옮바르지 않습니다");
			System.out.println("초기 메뉴로 돌아갑니다");
		}
		return check;

	}

	// 예약
	public static void New_Reservation_Insert(Connection conn, Statement stmt, String rrn) {

		String sql = ""; // 예약에 필요한 정보 입력
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		System.out.println();
		String Car_Number = null;
		String Car_Model = null;
		String Disabled_vehicle = null;
		String full_state = "Y";

		Scanner scanner = new Scanner(System.in);
		System.out.print("DATE(yyyy-mm-dd): ");
		String date = scanner.next();
		System.out.print("HOW MANY PERSON COME(num <= 40): ");
		Integer nop = scanner.nextInt();
		System.out.print("STORE ID: ");
		Integer storeid = scanner.nextInt();
		System.out.print("USE PARKING LOT??(Y or N):  ");// 주차장 예약은 옵션
		String parking = scanner.next();

		try {
			// 이미 예약을 한 정보가 있다면 경고후 return
			sql = "SELECT Rno " + "FROM STORE_RESERVATION WHERE RRN = " + rrn;
			rs = stmt.executeQuery(sql);
			Integer check = 0;
			if (rs.next()) {
				check = rs.getInt(1);
				if (check != 0) {
					System.out.println("You already reserve!");
					return;
				}
			}
			if (parking.equals("Y")) {
				sql = "SELECT * " + "FROM CAR WHERE CRRN = " + rrn;
				rs = stmt.executeQuery(sql);
				String check1 = null;
				if (rs.next()==false) {
					if (check1 == null) {
						System.out.println("You don't reserve your car!");
						System.out.println("You must reserve your car first!");
						return;
					}
				}
				else
				{
					Car_Number = rs.getString(1);
					Car_Model = rs.getString(2);
					Disabled_vehicle = rs.getString(3);
					check1 = rs.getString(4);	
					System.out.println(check1);
				}
				
			}


			Integer Pno = null;
			if (parking.equals("Y")) {// 주차장 이용 원할시

				if (Disabled_vehicle.equals("N")) {// 장애인전용 자리 이용 불가 차량
					sql = "SELECT Pno " + "FROM PARKING_LOT  " + "WHERE UseAble = 'Y' "
							+ "and Disable_Vehicle_Area = 'N' ";
					rs = stmt.executeQuery(sql);
					if (rs.next())
						Pno = rs.getInt(1);
				}

				if (Disabled_vehicle.equals("Y")) {// 장애인전용 자리 이용 가능 차량
					sql = "SELECT Pno " + "FROM PARKING_LOT  " + "WHERE UseAble = 'Y' "
							+ "and Disable_Vehicle_Area = 'Y' ";
					rs = stmt.executeQuery(sql);

					if (rs.next())
						Pno = rs.getInt(1);
					else {// 장애인전용 자리가 다 사용중일 경우 일반 자리 이용
						sql = "SELECT Pno " + "FROM PARKING_LOT  " + "WHERE UseAble = 'Y' ";
						rs = stmt.executeQuery(sql);

						if (rs.next())
							Pno = rs.getInt(1);
					}
				}

				if (Pno == null) {// 주차장 자리없는 경우 가게예약만이라도 할지 물어봄
					System.out.print("Parking lot is full statement ");
						return;
				}
			}

			// 예약을 원하는 가게에 자리가 있는지
			int need_table_count;
			if (nop % 4 == 0)
				need_table_count = nop / 4;
			else
				need_table_count = nop / 4 + 1;

			sql = "SELECT Tno " + "FROM SEAT_INFO WHERE Enable_Reservation = 'Y' AND SID = ?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, storeid);
			rs = pstmt.executeQuery();

			int[] table_no_array = new int[10];
			for (int i = 0; i < need_table_count; i++) {
				if (rs.next())
					table_no_array[i] = rs.getInt(1);
				else {
					System.err.println("필요한 테이블수가 부족합니다. 죄송합니다. ");
					return;
				}
			}
			// 예약번호 확인
			sql = "SELECT Rno " + "FROM STORE_RESERVATION  ";
			rs = stmt.executeQuery(sql);
			int size = 0;
			while (rs.next())
				size++;
			int rno = size + 1;

			// 예약정보 삽입
			sql = "INSERT INTO STORE_RESERVATION (Rno,RDate,NoP,Sno,RRN) VALUES(?,?,?,?,?)";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, rno);
			pstmt.setDate(2, java.sql.Date.valueOf(date));
			pstmt.setInt(3, nop);
			pstmt.setInt(4, storeid);
			pstmt.setString(5, rrn);

			pstmt.executeUpdate();
			System.out.println("Your store reservation no is '" + rno + "'");

			// 예약정보에 따른 자리 업데이트
			sql = "UPDATE SEAT_INFO SET Enable_Reservation = ? , Rno =?  WHERE Tno = ? and sid = " + storeid;
			pstmt = conn.prepareStatement(sql);

			for (int i = 0; i < need_table_count; i++) {

				pstmt.setString(1, "N");
				pstmt.setInt(2, rno);
				pstmt.setInt(3, table_no_array[i]);
				pstmt.executeUpdate();
			}
			System.out.print("Your reservation seat no is ");
			for (int i = 0; i < need_table_count; i++) {
				System.out.print("'" + table_no_array[i] + "' ");
			}
			if (Pno != null) {// 주차예약 정보 업데이트

				sql = "SELECT Rno FROM PARKING_RESERVATION  ";
				rs = stmt.executeQuery(sql);

				size = 0;
				while (rs.next())
					size++;
				/*
				 * if (rs != null) { rs.last(); // moves cursor to the last row size =
				 * rs.getRow(); // get row id rs.beforeFirst(); }
				 */
				int crno = size + 1;

				sql = "INSERT INTO PARKING_RESERVATION (Rno,Cno,PRDate,Pno,Vehicle_Useable,RRN) VALUES(?,?,?,?,?,?)";
				pstmt = conn.prepareStatement(sql);
				pstmt.setInt(1, crno);
				pstmt.setString(2, Car_Number);
				pstmt.setDate(3, java.sql.Date.valueOf(date));
				pstmt.setInt(4, Pno);
				pstmt.setString(5, Disabled_vehicle);
				pstmt.setString(6, rrn);

				pstmt.executeUpdate();

				sql = "UPDATE PARKING_LOT SET UseAble = ? , Rno = ? WHERE Pno = ? ";
				pstmt = conn.prepareStatement(sql);
				pstmt.setString(1, "N");
				pstmt.setInt(2, crno);
				pstmt.setInt(3, Pno);

				pstmt.executeUpdate();

				System.out.println("You must park at '" + Pno + "'");

			}

			rs.close();
		} catch (SQLException ex2) {
			ex2.printStackTrace();
			return;
		}

		System.out.println("reservation is complete!! Thank you!!^^");

	}

	// 예약 정보 확인
	public static void Check_Reservation(Connection conn, Statement stmt, String rrn) {

		String sql = ""; // rrn을 토대로 등록된 예약 정보 출력
		ResultSet rs = null;
		System.out.println();
		int check_s = 0;
		int check_p = 0;

		try {
			Integer rno = 0;
			// print store reservation
			sql = "SELECT Rno, RDate, NoP, Sno " + "FROM STORE_RESERVATION " + "WHERE RRN = " + rrn;
			rs = stmt.executeQuery(sql);

			while (rs.next()) {
				if (check_s == 0)
					System.out
							.println("Reservation no" + " | " + "Date" + " | " + "NUM of Person" + " | " + "Store Id");
				check_s = 1;

				rno = rs.getInt(1);
				String RDate = rs.getString(2);
				Integer NoP = rs.getInt(3);
				Integer Sno = rs.getInt(4);

				System.out.println(rno + " | " + RDate + " | " + NoP + " | " + Sno);
			}
			if (check_s == 0)
				System.out.println("No Store reservation");

			// print reservation seat info
			else {
				sql = "SELECT Tno " + "FROM SEAT_INFO " + "WHERE Rno = " + rno;
				rs = stmt.executeQuery(sql);

				System.out.println("Table no");

				while (rs.next()) {
					Integer tno = rs.getInt(1);
					System.out.println(tno);
				}
			}
			// print parking_lot reservation no and date
			sql = "SELECT Rno, PRDate " + "FROM PARKING_RESERVATION " + "WHERE RRN = " + rrn;
			rs = stmt.executeQuery(sql);

			while (rs.next()) {
				if (check_p == 0)
					System.out.println("Reservation no" + " | " + "Date" + " | ");
				check_p = 1;

				rno = rs.getInt(1);
				String rdate = rs.getString(2);

				System.out.println(rno + " | " + rdate);
			}
			if (check_p == 0)
				System.out.println("No Parking lot reservation");

			else {// print parking location
				sql = "SELECT PFloor, Location, Pno " + "FROM PARKING_LOT " + "WHERE Rno = " + rno;
				rs = stmt.executeQuery(sql);

				System.out.println("PFloor | Location | Pno");

				while (rs.next()) {
					String pfloor = rs.getString(1);
					String location = rs.getString(2);
					Integer pno = rs.getInt(3);

					System.out.println(pfloor + " | " + location + " | " + pno);
				}
			}
			System.out.println();

			rs.close();

		} catch (SQLException ex2) {
			System.err.println("sql error = " + ex2.getMessage());
			return;
		}

	}

	// 예약 취소
	public static void Cancel_Reservation(Connection conn, Statement stmt, String rrn) {

		String sql = ""; // rrn기반으로 등록된 정보 찾아서 취소하는 기능
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		System.out.println();

		Scanner scanner = new Scanner(System.in);
		// 기능 실행하게 되면 모든 예약 정보 사라짐
		System.out.print("Do you agree delete all reservation?(Y or N): ");
		String input = scanner.next();
		if (input.equals("N"))
			return;
		else if (input.equals("Y"))
			try {// 등록된 가게예약 번호와 가게번호 찾아냄
				sql = "SELECT Rno, Sno " + "FROM STORE_RESERVATION " + "WHERE RRN = " + rrn;
				rs = stmt.executeQuery(sql);
				rs.next();
				Integer s_rno = rs.getInt(1);
				Integer sno = rs.getInt(2);
				// 가게예약번호로 예약되어있는 좌석 찾아서 빈자리로 수정
				sql = "SELECT Tno " + "FROM SEAT_INFO " + "WHERE Rno = " + s_rno;
				rs = stmt.executeQuery(sql);
				int[] tno = new int[10];
				int i = 0;
				while (rs.next()) {
					tno[i++] = rs.getInt(1);
				}

				sql = "UPDATE SEAT_INFO SET Enable_Reservation = 'Y', Rno = 0  WHERE SID = ? and  Tno = ? ";
				pstmt = conn.prepareStatement(sql);

				for (int j = 0; j < i; j++) {
					pstmt.setInt(1, sno);
					pstmt.setInt(2, tno[j]);
					pstmt.executeUpdate();
				}
				// 등록된 가게예약 번호로 정보 삭제
				sql = "DELETE FROM STORE_RESERVATION " + "WHERE Rno = " + s_rno;
				stmt.executeUpdate(sql);
				// 등록된 주차장예약 번호와 주차공간 번호 찾아냄
				sql = "SELECT Rno, Pno " + "FROM PARKING_RESERVATION " + "WHERE RRN = " + rrn;
				rs = stmt.executeQuery(sql);
				rs.next();

				Integer p_rno = rs.getInt(1);
				Integer pno = rs.getInt(2);
				// 주차공간 번호로 빈공간으로 수정
				sql = "UPDATE PARKING_LOT SET UseAble = 'Y' , Rno = 0   WHERE Pno = ? ";
				pstmt = conn.prepareStatement(sql);
				pstmt.setInt(1, pno);
				pstmt.executeUpdate();
				// 주차 예약 삭제
				sql = "DELETE FROM PARKING_RESERVATION " + "WHERE Rno = " + p_rno;
				stmt.executeUpdate(sql);

				System.out.println("Your reservation is all deteled ");

				rs.close();
			} catch (SQLException ex2) {
				return;
			}
	}

	// 등록된 내 차 확인
	public static void Print_My_Car(Connection conn, Statement stmt, String rrn) {

		String sql = ""; // 계정에 등록되어 있는 차량 출력
		ResultSet rs = null;
		int check = 0;
		try {
			System.out.println("Print my registed car infomation");

			sql = "SELECT * " + "FROM CAR " + "WHERE CRRN = " + rrn;
			rs = stmt.executeQuery(sql);

			while (rs.next()) {
				if (check == 0)
					System.out.println("Car_Number | Car_Model | Disabled_vehicle | CRRN");
				check = 1;
				String car_number = rs.getString(1);
				String car_model = rs.getString(2);
				String disabled_vehicle = rs.getString(3);
				String crrn = rs.getString(4);

				System.out.println(car_number + " | " + car_model + " | " + disabled_vehicle + " | " + crrn);
			}
			if (check == 0)
				System.out.println("Not regist your car");

		} catch (SQLException ex2) {
			System.err.println("Error! ");
			return;
		}

	}
	//차량 등록하기
	public static void Regist_My_Car(Connection conn, Statement stmt, String rrn) {

		String sql = ""; // rrn을 토대로 등록된 예약 정보 출력
		ResultSet rs = null;
		PreparedStatement pstmt = null;

		String Car_Number = null;
		String Car_Model = null;
		String Disabled_vehicle = null;

		Scanner scanner = new Scanner(System.in);
		System.out.print("CAR NEMBER: ");
		Car_Number = scanner.next();
		System.out.print("CAR MODEL:  ");
		Car_Model = scanner.next();
		System.out.print("DISABLED VEHICLE(Y or N):  ");
		Disabled_vehicle = scanner.next();

		try {

			// 이미 등록한 차가 있다면 경고후 return
			sql = "SELECT CRRN " + "FROM CAR WHERE CRRN = " + rrn;
			rs = stmt.executeQuery(sql);
			String check = null;
			if (rs.next()) {
				check = rs.getString(1);
				if (check != null) {
					System.out.println("You already regist your car!");
					return;
				}
			}

			sql = "INSERT INTO CAR (Car_Number,Car_Model,Disabled_vehicle,CRRN) VALUES(?,?,?,?)";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, Car_Number);
			pstmt.setString(2, Car_Model);
			pstmt.setString(3, Disabled_vehicle);
			pstmt.setString(4, rrn);
			pstmt.executeUpdate();
			System.out.println("regist your car success! ");

		} catch (SQLException ex2) {
			System.err.println("Error! ");
			return;
		}
	}

	public static String[] Insert_Data(Integer n) {
		Scanner scanner = new Scanner(System.in);
		String input_data = scanner.nextLine();
		String[] input = input_data.split(" ");

		return input;
	}

	// insert
	public static void do_Insert(Connection conn, Statement stmt) {

		String sql = ""; // 원하는 테이블에 정보 삽입하는 기능
		Scanner scanner = new Scanner(System.in);
		PreparedStatement pstmt = null;

		String table_name = null;

		try { // insert data part
			table_name = null;

			System.out.print("Choose Table(capital letter!): ");
			table_name = scanner.next();

			/*
			 * if (insert_value[8].equals("NULL")) { pstmt.setNull(9, Types.INTEGER); } else
			 * pstmt.setString(9, insert_value[8]);
			 */

			// System.out.println(Arrays.toString(insert_value));
			if (table_name.equals("CUSTOMER")) {
				System.out.println("Enter a space between order by RRN,Sex,Birth,Name: ");
				String[] insert_value = Insert_Data(4);
				sql = "INSERT INTO CUSTOMER (RRN,Sex,Birth,Name) VALUES(?,?,?,?)";
				pstmt = conn.prepareStatement(sql);
				pstmt.setString(1, insert_value[0]);
				pstmt.setString(2, insert_value[1]);
				pstmt.setDate(3, java.sql.Date.valueOf(insert_value[2]));
				pstmt.setString(4, insert_value[3]);
				pstmt.executeUpdate();
				System.out.println("succes insert data!");

			} else if (table_name.equals("CAR")) {
				System.out.println("Enter a space between order by (Car_Number,Car_Model, Disabled_vehicle, CRRN): ");
				String[] insert_value = Insert_Data(4);
				sql = "INSERT INTO CAR (Car_Number,Car_Model, Disabled_vehicle, CRRN) VALUES(?,?,?,?)";
				pstmt = conn.prepareStatement(sql);
				pstmt.setString(1, insert_value[0]);
				pstmt.setString(2, insert_value[1]);
				pstmt.setString(3, insert_value[2]);
				pstmt.setString(4, insert_value[3]);
				pstmt.executeUpdate();
				System.out.println("succes insert data!");

			} else if (table_name.equals("DEPARTMENT")) {
				System.out.println("Enter a space between order by (Dnumber, Dname): ");
				String[] insert_value = Insert_Data(2);
				sql = "INSERT INTO DEPENDENT (Dnumber, Dname) VALUES(?,?)";
				pstmt = conn.prepareStatement(sql);
				pstmt.setString(1, insert_value[0]);
				pstmt.setString(2, insert_value[1]);
				pstmt.executeUpdate();
				System.out.println("succes insert data!");

			} else if (table_name.equals("STORE")) {
				System.out.println(
						"Enter a space between order by (STORE_ID,Store_Location, Opening_Hours, Closing_Hours, MAX_TC, Dno): ");
				String[] insert_value = Insert_Data(6);
				sql = "INSERT INTO STORE (STORE_ID,Store_Location, Opening_Hours, Closing_Hours, MAX_TC, Dno) VALUES(?,?,?,?,?,?)";
				pstmt = conn.prepareStatement(sql);
				pstmt.setInt(1, Integer.parseInt(insert_value[0]));
				pstmt.setString(2, insert_value[1]);
				pstmt.setString(3, insert_value[2]);
				pstmt.setString(4, insert_value[3]);
				pstmt.setInt(5, Integer.parseInt(insert_value[4]));
				pstmt.setInt(6, Integer.parseInt(insert_value[5]));

				pstmt.executeUpdate();
				System.out.println("succes insert data!");

			} else if (table_name.equals("EMPLOYEE")) {
				System.out.println("Enter a space between order by (EID, Sex, Name, Birth, Dno, Sid): ");
				String[] insert_value = Insert_Data(6);
				sql = "INSERT INTO EMPLOYEE (EID, Sex, Name, Birth, Dno, Sid) VALUES(?,?,?,?,?,?)";
				pstmt = conn.prepareStatement(sql);
				pstmt.setInt(1, Integer.parseInt(insert_value[0]));
				pstmt.setString(2, insert_value[1]);
				pstmt.setString(3, insert_value[2]);
				pstmt.setDate(4, java.sql.Date.valueOf(insert_value[3]));
				pstmt.setInt(5, Integer.parseInt(insert_value[4]));
				pstmt.setInt(6, Integer.parseInt(insert_value[5]));

				pstmt.executeUpdate();
				System.out.println("succes insert data!");

			} else if (table_name.equals("PARKING_LOT")) {
				System.out.println(
						"Enter a space between order by (PFloor, Location, Pno, UseAble, Disable_Vehicle_Area, PDate, Dno, Rno): ");
				String[] insert_value = Insert_Data(8);
				sql = "INSERT INTO PARKING_LOT (PFloor, Location, Pno, UseAble, Disable_Vehicle_Area, PDate, Dno, Rno) VALUES(?,?,?,?,?,?,?,?)";
				pstmt = conn.prepareStatement(sql);
				pstmt.setString(1, insert_value[0]);
				pstmt.setString(2, insert_value[1]);
				pstmt.setInt(3, Integer.parseInt(insert_value[2]));
				pstmt.setString(4, insert_value[3]);
				pstmt.setString(5, insert_value[4]);
				pstmt.setDate(6, java.sql.Date.valueOf(insert_value[5]));
				pstmt.setInt(7, Integer.parseInt(insert_value[6]));
				pstmt.setInt(8, Integer.parseInt(insert_value[7]));


				pstmt.executeUpdate();
				System.out.println("succes insert data!");

			} else if (table_name.equals("STORE_RESERVATION")) {
				System.out.println("Enter a space between order by (Rno, RDate, NoP, Sno, RRN): ");
				String[] insert_value = Insert_Data(5);
				sql = "INSERT INTO STORE_RESERVATION (Rno, RDate, NoP, Sno, RRN) VALUES(?,?,?,?,?)";
				pstmt = conn.prepareStatement(sql);
				pstmt.setInt(1, Integer.parseInt(insert_value[0]));
				pstmt.setDate(2, java.sql.Date.valueOf(insert_value[1]));
				pstmt.setInt(3, Integer.parseInt(insert_value[2]));
				pstmt.setInt(4, Integer.parseInt(insert_value[3]));
				pstmt.setString(5, insert_value[4]);

				pstmt.executeUpdate();
				System.out.println("succes insert data!");

			} else if (table_name.equals("PARKING_RESERVATION")) {
				System.out.println("Enter a space between order by (Rno, Cno, PRDate, Pno, Vehicle_Useable, RRN): ");
				String[] insert_value = Insert_Data(6);
				sql = "INSERT INTO PARKING_RESERVATION (Rno, Cno, PRDate, Pno, Vehicle_Useable, RRN) VALUES(?,?,?,?,?,?)";
				pstmt = conn.prepareStatement(sql);
				pstmt.setInt(1, Integer.parseInt(insert_value[0]));
				pstmt.setString(2, insert_value[1]);
				pstmt.setDate(3, java.sql.Date.valueOf(insert_value[2]));
				pstmt.setInt(4, Integer.parseInt(insert_value[3]));
				pstmt.setString(5, insert_value[4]);
				pstmt.setString(6, insert_value[5]);

				pstmt.executeUpdate();
				System.out.println("succes insert data!");

			} else if (table_name.equals("DISCOUNT")) {
				System.out.println("Enter a space between order by (SID, DCName, How, DCPercent ): ");
				String[] insert_value = Insert_Data(4);
				sql = "INSERT INTO DISCOUNT (SID, DCName, How, DCPercent ) VALUES(?,?,?,?)";
				pstmt = conn.prepareStatement(sql);
				pstmt.setInt(1, Integer.parseInt(insert_value[0]));
				pstmt.setString(2, insert_value[1]);
				pstmt.setString(3, insert_value[2]);
				pstmt.setInt(4, Integer.parseInt(insert_value[3]));

				pstmt.executeUpdate();
				System.out.println("succes insert data!");

			} else if (table_name.equals("SEAT_INFO")) {
				System.out.println("Enter a space between order by (SID, Tno, Maxnum, Enable_Reservation ): ");
				String[] insert_value = Insert_Data(4);
				sql = "INSERT INTO SEAT_INFO (SID, Tno, Maxnum, Enable_Reservation ) VALUES(?,?,?,?)";
				pstmt = conn.prepareStatement(sql);
				pstmt.setInt(1, Integer.parseInt(insert_value[0]));
				pstmt.setInt(2, Integer.parseInt(insert_value[1]));
				pstmt.setInt(3, Integer.parseInt(insert_value[2]));
				pstmt.setString(4, insert_value[3]);

				pstmt.executeUpdate();
				System.out.println("Succes Insert Data!");

			} else {
				System.out.println("Not Choose!");

			}

		} catch (SQLException ex2) {
			// System.err.println("sql error = " + ex2.getMessage());
			System.out.println("Error!!");
			return;
		}

	}
	//delete
	public static void do_Delete(Connection conn, Statement stmt) {

		String sql = ""; // 원하는 테이블에 정보 삭제하는 기능
		PreparedStatement pstmt = null;
		String table_name = null;
		String input_str = null;
		String input_str1 = null;

		Integer input_int = null;
		Integer input_int1 = null;

		Scanner scanner = new Scanner(System.in);
		try {
			System.out.print("Choose Table(capital letter!): ");
			table_name = scanner.next();

			if (table_name.equals("CUSTOMER")) {
				System.out.print("Which RRN?: ");
				input_str = scanner.next();
				sql = "DELETE FROM CUSTOMER " + "WHERE RRN = ? ";
				pstmt = conn.prepareStatement(sql);
				pstmt.setString(1, input_str);

				pstmt.executeUpdate();
				System.out.println("succes delete data!");

			} else if (table_name.equals("CAR")) {
				System.out.print("Which CAR_NUMBER?: ");
				input_str = scanner.next();
				sql = "DELETE FROM CAR " + "WHERE CAR_NUMBER = ?";
				pstmt = conn.prepareStatement(sql);
				pstmt.setString(1, input_str);

				pstmt.executeUpdate();
				System.out.println("succes delete data!");

			} else if (table_name.equals("DEPARTMENT")) {
				System.out.print("Which Dnumber?: ");
				input_int = scanner.nextInt();
				sql = "DELETE FROM DEPARTMENT " + "WHERE Dnumber = ?";
				pstmt = conn.prepareStatement(sql);
				pstmt.setInt(1, input_int);

				pstmt.executeUpdate();
			} else if (table_name.equals("STORE")) {
				System.out.print("Which STORE_ID?: ");
				input_int = scanner.nextInt();
				sql = "DELETE FROM STORE " + "WHERE STORE_ID = ?";
				pstmt = conn.prepareStatement(sql);
				pstmt.setInt(1, input_int);

				pstmt.executeUpdate();
				System.out.println("succes delete data!");

			} else if (table_name.equals("EMPLOYEE")) {
				System.out.print("Which EID?: ");
				input_int = scanner.nextInt();
				sql = "DELETE FROM EMPLOYEE " + "WHERE EID = ?";
				pstmt = conn.prepareStatement(sql);
				pstmt.setInt(1, input_int);

				pstmt.executeUpdate();
				System.out.println("succes delete data!");

			} else if (table_name.equals("PARKING_LOT")) {
				System.out.print("Which Pno?: ");
				input_int = scanner.nextInt();
				System.out.print("Which PDate?: ");
				input_str1 = scanner.next();
				sql = "DELETE FROM PARKING_LOT " + "WHERE Pno = ? and PDate = ?";
				pstmt = conn.prepareStatement(sql);
				pstmt.setInt(1, input_int);
				pstmt.setDate(2, java.sql.Date.valueOf(input_str1));

				pstmt.executeUpdate();
				System.out.println("succes delete data!");

			} else if (table_name.equals("STORE_RESERVATION")) {
				System.out.print("Which Rno?: ");
				input_int = scanner.nextInt();
				sql = "DELETE FROM STORE_RESERVATION " + "WHERE Rno = ?";
				pstmt = conn.prepareStatement(sql);
				pstmt.setInt(1, input_int);

				pstmt.executeUpdate();
				System.out.println("succes delete data!");

			} else if (table_name.equals("PARKING_RESERVATION")) {
				System.out.print("Which Rno?: ");
				input_int = scanner.nextInt();
				sql = "DELETE FROM PARKING_RESERVATION " + "WHERE Rno = ?";
				pstmt = conn.prepareStatement(sql);
				pstmt.setInt(1, input_int);

				pstmt.executeUpdate();
				System.out.println("succes delete data!");

			} else if (table_name.equals("DISCOUNT")) {
				System.out.print("Which STORE_ID?: ");
				input_int = scanner.nextInt();
				System.out.print("Which DCName?: ");
				input_str1 = scanner.next();
				sql = "DELETE FROM DISCOUNT " + "WHERE SID = ? and DCName = ?";
				pstmt = conn.prepareStatement(sql);
				pstmt.setInt(1, input_int);
				pstmt.setString(2, input_str);

				pstmt.executeUpdate();
				System.out.println("succes delete data!");

			} else if (table_name.equals("SEAT_INFO")) {
				System.out.print("Which STORE_ID?: ");
				input_int = scanner.nextInt();
				System.out.print("Which Tno?: ");
				input_int1 = scanner.nextInt();
				sql = "DELETE FROM SEAT_INFO " + "WHERE SID = ? and Tno = ?";
				pstmt = conn.prepareStatement(sql);
				pstmt.setInt(1, input_int);
				pstmt.setInt(2, input_int1);

				pstmt.executeUpdate();
				System.out.println("succes delete data!");

			}

		} catch (SQLException ex2) {
			System.err.println("sql error = " + ex2.getMessage());

		}
	}

	// search
	public static void do_Search(Connection conn, Statement stmt) {

		String sql = ""; // 원하는 테이블에 정보 검색하는 기능
		Scanner scanner = new Scanner(System.in);
		ResultSet rs = null;
		String table_name = null;
		int check = 0;
		try { // print wanted table data
			table_name = null;

			System.out.print("Choose Table(capital letter!): ");
			table_name = scanner.next();

			if (table_name.equals("CUSTOMER")) {

				sql = "select * from CUSTOMER";
				rs = stmt.executeQuery(sql);
				while (rs.next()) {
					if (check == 0)
						System.out.println("RRN | Sex | Birth | Name");
					check = 1;
					String rrn = rs.getString(1);
					String sex = rs.getString(2);
					String birth = rs.getString(3);
					String name = rs.getString(4);

					System.out.println(rrn + " | " + sex + " | " + birth + " | " + name);
				}

			} else if (table_name.equals("CAR")) {

				sql = "SELECT * FROM CAR";
				rs = stmt.executeQuery(sql);
				while (rs.next()) {
					if (check == 0)
						System.out.println("Car_Number | Car_Model | Disabled_vehicle | CRRN");
					check = 1;
					String car_number = rs.getString(1);
					String car_model = rs.getString(2);
					String disabled_vehicle = rs.getString(3);
					String crrn = rs.getString(4);

					System.out.println(car_number + " | " + car_model + " | " + disabled_vehicle + " | " + crrn);
				}

			} else if (table_name.equals("DEPARTMENT")) {
				sql = "SELECT * FROM DEPARTMENT";
				rs = stmt.executeQuery(sql);
				while (rs.next()) {
					if (check == 0)
						System.out.println("Dnumber | Dname ");
					check = 1;
					Integer dnumber = rs.getInt(1);
					String dname = rs.getString(2);

					System.out.println(dnumber + " | " + dname);
				}

			} else if (table_name.equals("STORE")) {
				sql = "SELECT * FROM STORE";
				rs = stmt.executeQuery(sql);
				while (rs.next()) {
					if (check == 0)
						System.out.println("STORE_ID | Store_Location | Opening_Hours | Closing_Hours | MAX_TC | Dno");
					check = 1;
					String STORE_ID = rs.getString(1);
					String Store_Location = rs.getString(2);
					String Opening_Hours = rs.getString(3);
					String Closing_Hours = rs.getString(4);
					Integer MAX_TC = rs.getInt(5);
					Integer Dno = rs.getInt(6);

					System.out.println(STORE_ID + " | " + Store_Location + " | " + Opening_Hours + " | " + Closing_Hours
							+ " | " + MAX_TC + " | " + Dno);
				}

			} else if (table_name.equals("EMPLOYEE")) {

				sql = "SELECT * FROM EMPLOYEE";
				rs = stmt.executeQuery(sql);
				while (rs.next()) {
					if (check == 0)
						System.out.println("EID | Sex | Name | Birth | Dno | Sid");
					check = 1;
					Integer EID = rs.getInt(1);
					String Sex = rs.getString(2);
					String Name = rs.getString(3);
					String Birth = rs.getString(4);
					Integer Dno = rs.getInt(5);
					Integer Sid = rs.getInt(6);

					System.out.println(EID + " | " + Sex + " | " + Name + " | " + Birth + " | " + Dno + " | " + Sid);
				}

			} else if (table_name.equals("PARKING_LOT")) {

				sql = "SELECT * FROM PARKING_LOT";
				rs = stmt.executeQuery(sql);
				while (rs.next()) {
					if (check == 0)
						System.out.println("PFloor | Location | Pno | UseAble | Disable_Vehicle_Area | PDate | Dno | Rno");
					check = 1;
					String PFloor = rs.getString(1);
					String Location = rs.getString(2);
					Integer Pno = rs.getInt(3);
					String UseAble = rs.getString(4);
					String Disable_Vehicle_Area = rs.getString(5);
					String PDate = rs.getString(6);
					Integer Dno = rs.getInt(7);
					Integer Rno = rs.getInt(8);

					System.out.println(PFloor + " | " + Location + " | " + Pno + " | " + UseAble + " | "
							+ Disable_Vehicle_Area + " | " + PDate + " | " + Dno + " | " + Rno);
				}

			} else if (table_name.equals("STORE_RESERVATION")) {

				sql = "SELECT * FROM STORE_RESERVATION";
				rs = stmt.executeQuery(sql);
				while (rs.next()) {
					if (check == 0)
						System.out.println("Rno | RDate | NoP | Sno | RRN");
					check = 1;
					Integer Rno = rs.getInt(1);
					String RDate = rs.getString(2);
					Integer NoP = rs.getInt(3);
					Integer Sno = rs.getInt(4);
					String RRN = rs.getString(5);

					System.out.println(Rno + " | " + RDate + " | " + NoP + " | " + Sno + " | " + RRN);
				}

			} else if (table_name.equals("PARKING_RESERVATION")) {
				sql = "SELECT * FROM PARKING_RESERVATION";
				rs = stmt.executeQuery(sql);
				while (rs.next()) {
					if (check == 0)
						System.out.println("Rno | Cno | PRDate | Pno | Vehicle_Useable | RRN");
					check = 1;
					Integer Rno = rs.getInt(1);
					String Cno = rs.getString(2);
					String PRDate = rs.getString(3);
					Integer Pno = rs.getInt(4);
					String Vehicle_Useable = rs.getString(5);
					String RRN = rs.getString(6);

					System.out.println(
							Rno + " | " + Cno + " | " + PRDate + " | " + Pno + " | " + Vehicle_Useable + " | " + RRN);
				}

			} else if (table_name.equals("DISCOUNT")) {
				sql = "SELECT * FROM DISCOUNT";
				rs = stmt.executeQuery(sql);
				while (rs.next()) {
					if (check == 0)
						System.out.println("SID | DCName | How | DCPercent");
					check = 1;
					Integer SID = rs.getInt(1);
					String DCName = rs.getString(2);
					String How = rs.getString(3);
					Integer DCPercent = rs.getInt(4);

					System.out.println(SID + " | " + DCName + " | " + How + " | " + DCPercent);
				}

			} else if (table_name.equals("SEAT_INFO")) {
				sql = "SELECT * FROM SEAT_INFO";
				rs = stmt.executeQuery(sql);
				while (rs.next()) {
					if (check == 0)
						System.out.println("SID | Tno | Maxnum | Enable_Reservation | Rno");
					check = 1;
					Integer SID = rs.getInt(1);
					Integer Tno = rs.getInt(2);
					Integer Maxnum = rs.getInt(3);
					String Enable_Reservation = rs.getString(4);
					Integer Rno = rs.getInt(5);

					System.out.println(SID + " | " + Tno + " | " + Maxnum + " | " + Enable_Reservation + " | " + Rno);
				}
			} else {
				System.out.println("Not Choose!");

			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			return;
		}

	}

	// 가게 정보 검색
	public static void Search_Store(Connection conn, Statement stmt) {

		String sql = ""; // 특정 조건으로 가게 검색
		ResultSet rs = null;
		Scanner scanner = new Scanner(System.in);
		Integer input_num;
		Integer SID;
		String SLocation;
		try {
			System.out.println("1.SID  2.Store Location  3.Both");
			input_num = scanner.nextInt();
			if (input_num == 1) {

				System.out.print("Store Id: ");// 가게 ID로 검색
				SID = scanner.nextInt();
				sql = "SELECT STORE_ID, Store_Location " + "FROM STORE " + "WHERE STORE_ID = " + SID;
			} else if (input_num == 2) {// 위치로 검색
				System.out.print("Store Location: ");
				SLocation = scanner.next();
				sql = "SELECT STORE_ID, Store_Location " + "FROM STORE " + "WHERE Store_Location like '" + SLocation
						+ "' ";
			} else if (input_num == 3) {// 둘다 사용
				System.out.print("Store Id: ");
				SID = scanner.nextInt();
				System.out.print("Store Location: ");
				SLocation = scanner.next();
				sql = "SELECT STORE_ID, Store_Location " + "FROM STORE " + "WHERE STORE_ID = " + SID
						+ " and Store_Location like '" + SLocation + "' ";
			} else {
				System.out.println("input number 1~3 plz!");
				return;
			}
			rs = stmt.executeQuery(sql);
			System.out.println("STORE_ID | Store_Location");
			// 가게 번호 | 위치 출력
			while (rs.next()) {
				Integer STORE_ID = rs.getInt(1);
				String Store_Location = rs.getString(2);

				System.out.println(STORE_ID + " | " + Store_Location);
			}

		} catch (SQLException ex2) {
			// System.err.println("sql error = " + ex2.getMessage());
			System.err.println("Error! ");
			return;
		} catch (InputMismatchException ex2) {
			System.err.println("잘못된 입력입니다 ");
			return;
		}

	}

	// 가게의 이용 가능한 자리 검색
	public static void Search_Store_Seat(Connection conn, Statement stmt) {

		String sql = "";
		ResultSet rs = null;
		Scanner scanner = new Scanner(System.in);
		System.out.print("Store ID: ");
		Integer SID = scanner.nextInt();
		Integer enable_table_count = 0;
		try {

			sql = "SELECT SID, Tno " + "FROM SEAT_INFO " + "WHERE Enable_Reservation = 'Y' " + "And SID = " + SID;
			rs = stmt.executeQuery(sql);
			// 이용가능한 테이블 수 출력
			while (rs.next())
				enable_table_count++;
			System.out.println("Can reserve table count = " + enable_table_count);

		} catch (SQLException ex2) {
			System.err.println("sql error = " + ex2.getMessage());
			return;
		}
	}

	// 가게의 할인 정보 검색
	public static void Search_Discount_Info(Connection conn, Statement stmt) {

		String sql = ""; // 할인 정보 검색하는 기능
		ResultSet rs = null;
		Scanner scanner = new Scanner(System.in);
		Integer SID;
		String DCName;
		String How;
		try {

			System.out.print("Store Id: ");// 특정 가게에 대한 할인 정보 검색
			SID = scanner.nextInt();
			System.out.print("DCName: ");// 할인 조건에 대한 정보검색
			DCName = scanner.next();
			// System.out.print("How: ");
			// How = scanner.next();
			sql = "SELECT SID, DCName, How, DCPercent " + "FROM DISCOUNT " + "WHERE SID = " + SID
					+ " and DCName like '%" + DCName + "%' ";
			// + "and How like '%" + How + "%'";

			rs = stmt.executeQuery(sql);
			System.out.println("SID | DCName | How | DCPercent");

			while (rs.next()) {
				SID = rs.getInt(1);
				DCName = rs.getString(2);
				How = rs.getString(3);
				Integer DCPercent = rs.getInt(4);
				System.out.println(SID + " | " + DCName + " | " + How + " | " + DCPercent);
			}

		} catch (SQLException ex2) {
			System.err.println("sql error = " + ex2.getMessage());
			return;
		}
	}

	// phase2 쿼리 구문 실행
	public static void Admin_Query(Connection conn, Statement stmt) {
		// phase2에서 만든 쿼리구문 출력 (정상작동하는지 알수 있음)
		ResultSet rs = null;
		try {

			conn = DriverManager.getConnection(URL, USER_ID, USER_PASSWD);
			stmt = conn.createStatement();

			String sql = "SELECT pno " + "FROM PARKING_LOT " + "WHERE PFloor = 'B1' ";
			rs = stmt.executeQuery(sql);
			System.out.println("<< query 1 result >>");
			System.out.println("pno");

			while (rs.next()) {
				// Fill out your code
				Integer pno = rs.getInt(1);
				System.out.println(pno);
			}

			System.out.println();

			sql = "SELECT name " + "FROM employee " + "WHERE dno = 5 ";
			rs = stmt.executeQuery(sql);
			System.out.println("<< query 2 result >>");
			System.out.println("name");

			while (rs.next()) {
				// Fill out your code
				String name = rs.getString(1);
				System.out.println(name);
			}
			System.out.println();

			sql = "SELECT car_model, name " + "FROM CUSTOMER, CAR " + "WHERE RRN = CRRN " + " AND RRN = '2603200' ";
			rs = stmt.executeQuery(sql);
			System.out.println("<< query 3 result >>");
			System.out.println("car_model  |  name");

			while (rs.next()) {
				// Fill out your code
				String car_model = rs.getString(1);
				String name = rs.getString(2);
				System.out.println(car_model + " | " + name);
			}
			System.out.println();

			sql = "SELECT car_number, name " + "FROM CUSTOMER, CAR " + "WHERE RRN = CRRN " + " AND "
					+ " Disabled_vehicle = 'Y' ";
			rs = stmt.executeQuery(sql);
			System.out.println("<< query 4 result >>");
			System.out.println("car_number  |  name");

			while (rs.next()) {
				// Fill out your code
				String car_number = rs.getString(1);
				String name = rs.getString(2);
				System.out.println(car_number + " | " + name);
			}
			System.out.println();

			sql = "SELECT dno, count(*) as allemp " + "FROM employee " + "group by dno ";
			rs = stmt.executeQuery(sql);
			System.out.println("<< query 5 result >>");
			System.out.println("dno  |  allemp");

			while (rs.next()) {
				// Fill out your code
				String dno = rs.getString(1);
				Integer allemp = rs.getInt(2);
				System.out.println(dno + " | " + allemp);
			}
			System.out.println();

			sql = "SELECT car_model, count(*) as ncars " + "FROM car " + "group by car_model ";
			rs = stmt.executeQuery(sql);
			System.out.println("<< query 6 result >>");
			System.out.println("car_model  |  ncars");

			while (rs.next()) {
				// Fill out your code
				String car_model = rs.getString(1);
				Integer ncars = rs.getInt(2);
				System.out.println(car_model + " | " + ncars);
			}
			System.out.println();

			sql = "SELECT pno " + "FROM PARKING_LOT "
					+ "where pfloor = 'B2' and Disable_Vehicle_Area = 'Y' and UseAble = 'Y' " + "group by pno";
			rs = stmt.executeQuery(sql);
			System.out.println("<< query 7 result >>");
			System.out.println("pno");

			while (rs.next()) {
				// Fill out your code
				Integer pno = rs.getInt(1);
				System.out.println(pno);
			}
			System.out.println();

			sql = "select car_model, count(*) as ncars from (select car_model from car where Disabled_vehicle = 'Y' ) group by car_model ";
			rs = stmt.executeQuery(sql);
			System.out.println("<< query 8 result >>");
			System.out.println("car_model  |  ncars");

			while (rs.next()) {
				String car_model = rs.getString(1);
				Integer ncars = rs.getInt(2);
				System.out.println(car_model + " | " + ncars);
			}
			System.out.println();

			sql = "select store.STORE_ID, Tno from store,(select tno from seat_info where enable_reservation = 'Y')where Store_Location like 'F2%' ";
			rs = stmt.executeQuery(sql);
			System.out.println("<< query 9 result >>");
			System.out.println("STORE_ID  |  tno");

			while (rs.next()) {
				String STORE_ID = rs.getString(1);
				Integer tno = rs.getInt(2);
				System.out.println(STORE_ID + " | " + tno);
			}
			System.out.println();

			sql = "select distinct tno from seat_info where exists(select * from seat_info where SID = 1 and Enable_Reservation = 'Y') "
					+ "order by tno asc ";
			rs = stmt.executeQuery(sql);
			System.out.println("<< query 10 result >>");
			System.out.println("tno");

			while (rs.next()) {
				Integer tno = rs.getInt(1);
				System.out.println(tno);
			}
			System.out.println();

			sql = "select distinct tno from seat_info where (tno) IN (select tno from seat_info where SID = 1 and Enable_Reservation = 'Y') ";
			rs = stmt.executeQuery(sql);
			System.out.println("<< query 11 result >>");
			System.out.println("tno");

			while (rs.next()) {
				Integer tno = rs.getInt(1);
				System.out.println(tno);
			}
			System.out.println();

			sql = "select Store_ID from store where MAX_TC >= all(select MAX_TC from store) ";
			rs = stmt.executeQuery(sql);
			System.out.println("<< query 12 result >>");
			System.out.println("Store_ID");

			while (rs.next()) {
				Integer Store_ID = rs.getInt(1);
				System.out.println(Store_ID);
			}
			System.out.println();

			sql = "with nusemp as (select sid, count(sid) as nuemp from employee group by sid having count(sid) >= 3) "
					+ "select store_id, MAX_TC from store, nusemp where nusemp.sid = store_id";
			rs = stmt.executeQuery(sql);
			System.out.println("<< query 13 result >>");
			System.out.println("Store_ID | MAX_TC");

			while (rs.next()) {
				Integer Store_ID = rs.getInt(1);
				Integer MAX_TC = rs.getInt(2);
				System.out.println(Store_ID + " | " + MAX_TC);
			}
			System.out.println();

			sql = "with numstr as (select dno, count(dno) as nusto from store group by dno having count(dno) >= 3) "
					+ "select name, employee.dno from employee, numstr where employee.dno = numstr.dno ";
			rs = stmt.executeQuery(sql);
			System.out.println("<< query 14 result >>");
			System.out.println("name | dnumber");

			while (rs.next()) {
				String name = rs.getString(1);
				Integer dnumber = rs.getInt(2);
				System.out.println(name + " | " + dnumber);
			}
			System.out.println();

			sql = "select dname, STORE_ID, Dno, tno "
					+ "from ( ( seat_info join store on STORE_ID= SID ) join department on dno = dnumber ) "
					+ "where dno =2" + "order by dno desc";
			rs = stmt.executeQuery(sql);
			System.out.println("<< query 15 result >>");
			System.out.println("Dname | Store_ID | Dno | Tno");

			while (rs.next()) {
				String dname = rs.getString(1);
				Integer Store_ID = rs.getInt(2);
				Integer Dno = rs.getInt(3);
				Integer tno = rs.getInt(4);

				System.out.println(dname + " | " + Store_ID + " | " + Dno + " | " + tno);
			}
			System.out.println();

			sql = "select distinct rdate, name, store_reservation.rrn, car_model "
					+ "from((store_reservation join customer on store_reservation.rrn = customer.rrn) join car on crrn = customer.rrn) "
					+ "where sno = 5";
			rs = stmt.executeQuery(sql);
			System.out.println("<< query 16 result >>");
			System.out.println("rdate | name | rrn | car_model");

			while (rs.next()) {
				String rdate = rs.getString(1);
				String name = rs.getString(2);
				String rrn = rs.getString(3);
				String car_model = rs.getString(4);

				System.out.println(rdate + " | " + name + " | " + rrn + " | " + car_model);
			}
			System.out.println();

			sql = "select distinct Store_ID, max(tno) as max_tableseat, count(distinct eid) as em_num "
					+ "from((seat_info join store on STORE_ID = seat_info.SID) join employee on STORE_ID = employee.sid) "
					+ "group by store_id, max_tc " + "order by store_id";
			rs = stmt.executeQuery(sql);
			System.out.println("<< query 17 result >>");
			System.out.println("Store_ID | max_tableseat | em_num");

			while (rs.next()) {
				String Store_ID = rs.getString(1);
				Integer max_tableseat = rs.getInt(2);
				Integer em_num = rs.getInt(3);

				System.out.println(Store_ID + " | " + max_tableseat + " | " + em_num);
			}
			System.out.println();

			sql = "select Store_ID,  count(distinct eid) as em_num , count(distinct dcname) as discount_num "
					+ "from  ((store join employee on STORE_ID = employee.sid) left join discount on store_id = discount.sid) "
					+ "group by store_id " + "order by store_id ";
			rs = stmt.executeQuery(sql);
			System.out.println("<< query 18 result >>");
			System.out.println("Store_ID | em_num | discount_num");

			while (rs.next()) {
				String Store_ID = rs.getString(1);
				Integer em_num = rs.getInt(2);
				Integer discount_num = rs.getInt(3);

				System.out.println(Store_ID + " | " + em_num + " | " + discount_num);
			}
			System.out.println();

			sql = "select * from customer " + "where (name) in(select name from customer where sex='F') " + "INTERSECT "
					+ "select * from customer where name like '%이%' ";
			rs = stmt.executeQuery(sql);
			System.out.println("<< query 19 result >>");
			System.out.println("RRN | Sex | Birth | Name");

			while (rs.next()) {
				String RRN = rs.getString(1);
				String Sex = rs.getString(2);
				String Birth = rs.getString(3);
				String Name = rs.getString(4);

				System.out.println(RRN + " | " + Sex + " | " + Birth + " | " + Name);
			}
			System.out.println();

			sql = "select * from employee " + "where sex='M' " + "minus " + "select * from employee where dno= 1 ";
			rs = stmt.executeQuery(sql);
			System.out.println("<< query 20 result >>");
			System.out.println("RRN | Sex | Birth | Name");

			while (rs.next()) {
				String RRN = rs.getString(1);
				String Sex = rs.getString(2);
				String Birth = rs.getString(3);
				String Name = rs.getString(4);

				System.out.println(RRN + " | " + Sex + " | " + Birth + " | " + Name);
			}
			System.out.println();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try {
			// Close the Statement object.
			stmt.close();
			// Close the Connection object.
			conn.close();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
